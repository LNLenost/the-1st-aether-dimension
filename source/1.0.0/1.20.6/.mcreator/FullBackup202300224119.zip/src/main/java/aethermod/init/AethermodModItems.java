
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package aethermod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;

import aethermod.item.SuperGlowstoneDustItem;
import aethermod.item.GlowstoneSwordItem;
import aethermod.item.GlowstoneShovelItem;
import aethermod.item.GlowstonePickaxeItem;
import aethermod.item.GlowstoneHoeItem;
import aethermod.item.GlowstoneAxeItem;
import aethermod.item.GlowstoneArmorItem;
import aethermod.item.GlowCarrotsItem;
import aethermod.item.AetherItem;

import aethermod.AethermodMod;

public class AethermodModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AethermodMod.MODID);
	public static final RegistryObject<Item> SPACE_COW_SPAWN_EGG = REGISTRY.register("space_cow_spawn_egg", () -> new ForgeSpawnEggItem(AethermodModEntities.SPACE_COW, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> AETHER = REGISTRY.register("aether", () -> new AetherItem());
	public static final RegistryObject<Item> SUPER_GLOWSTONE_DUST = REGISTRY.register("super_glowstone_dust", () -> new SuperGlowstoneDustItem());
	public static final RegistryObject<Item> GLOWSTONE_AXE = REGISTRY.register("glowstone_axe", () -> new GlowstoneAxeItem());
	public static final RegistryObject<Item> GLOWSTONE_PICKAXE = REGISTRY.register("glowstone_pickaxe", () -> new GlowstonePickaxeItem());
	public static final RegistryObject<Item> GLOWSTONE_SWORD = REGISTRY.register("glowstone_sword", () -> new GlowstoneSwordItem());
	public static final RegistryObject<Item> GLOWSTONE_SHOVEL = REGISTRY.register("glowstone_shovel", () -> new GlowstoneShovelItem());
	public static final RegistryObject<Item> GLOWSTONE_HOE = REGISTRY.register("glowstone_hoe", () -> new GlowstoneHoeItem());
	public static final RegistryObject<Item> GLOWSTONE_ARMOR_HELMET = REGISTRY.register("glowstone_armor_helmet", () -> new GlowstoneArmorItem.Helmet());
	public static final RegistryObject<Item> GLOWSTONE_ARMOR_CHESTPLATE = REGISTRY.register("glowstone_armor_chestplate", () -> new GlowstoneArmorItem.Chestplate());
	public static final RegistryObject<Item> GLOWSTONE_ARMOR_LEGGINGS = REGISTRY.register("glowstone_armor_leggings", () -> new GlowstoneArmorItem.Leggings());
	public static final RegistryObject<Item> GLOWSTONE_ARMOR_BOOTS = REGISTRY.register("glowstone_armor_boots", () -> new GlowstoneArmorItem.Boots());
	public static final RegistryObject<Item> GLOW_CARROTS = REGISTRY.register("glow_carrots", () -> new GlowCarrotsItem());
}
