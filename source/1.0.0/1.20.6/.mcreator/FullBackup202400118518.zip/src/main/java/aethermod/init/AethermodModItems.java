
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package aethermod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.bus.api.IEventBus;

import net.minecraft.world.item.Item;
import net.minecraft.core.registries.BuiltInRegistries;

import aethermod.item.SuperGlowstoneDustItem;
import aethermod.item.GlowstoneSwordItem;
import aethermod.item.GlowstoneShovelItem;
import aethermod.item.GlowstonePickaxeItem;
import aethermod.item.GlowstoneHoeItem;
import aethermod.item.GlowstoneAxeItem;
import aethermod.item.GlowstoneArmorItem;
import aethermod.item.GlowCarrotsItem;
import aethermod.item.AetherItem;

import aethermod.AethermodMod;

public class AethermodModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(BuiltInRegistries.ITEM, AethermodMod.MODID);
	public static final DeferredHolder<Item, Item> SPACE_COW_SPAWN_EGG = REGISTRY.register("space_cow_spawn_egg", () -> new DeferredSpawnEggItem(AethermodModEntities.SPACE_COW, -1, -1, new Item.Properties()));
	public static final DeferredHolder<Item, Item> AETHER = REGISTRY.register("aether", () -> new AetherItem());
	public static final DeferredHolder<Item, Item> SUPER_GLOWSTONE_DUST = REGISTRY.register("super_glowstone_dust", () -> new SuperGlowstoneDustItem());
	public static final DeferredHolder<Item, Item> GLOWSTONE_ARMOR_HELMET = REGISTRY.register("glowstone_armor_helmet", () -> new GlowstoneArmorItem.Helmet());
	public static final DeferredHolder<Item, Item> GLOWSTONE_ARMOR_CHESTPLATE = REGISTRY.register("glowstone_armor_chestplate", () -> new GlowstoneArmorItem.Chestplate());
	public static final DeferredHolder<Item, Item> GLOWSTONE_ARMOR_LEGGINGS = REGISTRY.register("glowstone_armor_leggings", () -> new GlowstoneArmorItem.Leggings());
	public static final DeferredHolder<Item, Item> GLOWSTONE_ARMOR_BOOTS = REGISTRY.register("glowstone_armor_boots", () -> new GlowstoneArmorItem.Boots());
	public static final DeferredHolder<Item, Item> GLOWSTONE_PICKAXE = REGISTRY.register("glowstone_pickaxe", () -> new GlowstonePickaxeItem());
	public static final DeferredHolder<Item, Item> GLOWSTONE_AXE = REGISTRY.register("glowstone_axe", () -> new GlowstoneAxeItem());
	public static final DeferredHolder<Item, Item> GLOWSTONE_SWORD = REGISTRY.register("glowstone_sword", () -> new GlowstoneSwordItem());
	public static final DeferredHolder<Item, Item> GLOWSTONE_SHOVEL = REGISTRY.register("glowstone_shovel", () -> new GlowstoneShovelItem());
	public static final DeferredHolder<Item, Item> GLOWSTONE_HOE = REGISTRY.register("glowstone_hoe", () -> new GlowstoneHoeItem());
	public static final DeferredHolder<Item, Item> GLOW_CARROTS = REGISTRY.register("glow_carrots", () -> new GlowCarrotsItem());

	// Start of user code block custom items
	// End of user code block custom items
	public static void register(IEventBus bus) {
		REGISTRY.register(bus);
	}
}
