
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package aethermod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import aethermod.AethermodMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AethermodModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AethermodMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(AethermodModItems.GLOWSTONE_SWORD.get());
			tabData.accept(AethermodModItems.GLOWSTONE_ARMOR_HELMET.get());
			tabData.accept(AethermodModItems.GLOWSTONE_ARMOR_CHESTPLATE.get());
			tabData.accept(AethermodModItems.GLOWSTONE_ARMOR_LEGGINGS.get());
			tabData.accept(AethermodModItems.GLOWSTONE_ARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(AethermodModItems.SPACE_COW_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(AethermodModItems.AETHER.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(AethermodModItems.SUPER_GLOWSTONE_DUST.get());
			tabData.accept(AethermodModItems.GLOWSTONE_AXE.get());
			tabData.accept(AethermodModItems.GLOWSTONE_PICKAXE.get());
			tabData.accept(AethermodModItems.GLOWSTONE_SHOVEL.get());
			tabData.accept(AethermodModItems.GLOWSTONE_HOE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(AethermodModItems.GLOW_CARROTS.get());
		}
	}
}
