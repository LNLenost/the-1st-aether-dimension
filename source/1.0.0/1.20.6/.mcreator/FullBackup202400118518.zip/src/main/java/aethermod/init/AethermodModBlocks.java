
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package aethermod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import aethermod.block.AetherPortalBlock;

import aethermod.AethermodMod;

public class AethermodModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, AethermodMod.MODID);
	public static final DeferredHolder<Block, Block> AETHER_PORTAL = REGISTRY.register("aether_portal", () -> new AetherPortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
